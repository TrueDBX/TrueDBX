const express = require("express");
const app = express();
const PORT = process.env.PORT || 3000;


// Middleware
app.use(express.json());
app.use(express.static("public"));

// Rotas
const userRoutes = require("./routes/users");
const flightRoutes = require("./routes/flights");
const hotelRoutes = require("./routes/hotels");
const carRoutes = require("./routes/cars");
const reservationRoutes = require("./routes/reservations");



const path = require("path");
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "HTML", "index.html"));
});

const session = require("express-session");
app.use(session({
  secret: "segredo_super_seguro",
  resave: false,
  saveUninitialized: false,
}));

app.use("/users", userRoutes);
app.use("/flights", flightRoutes);
app.use("/hotels", hotelRoutes);
app.use("/cars", carRoutes);
app.use("/reservations", reservationRoutes);

// Rota inicial
app.get("/", (req, res) => {
  res.send("🌍 Bem-vindo ao Sistema de Reservas de Viagens!");
});

// Iniciar servidor
app.listen(PORT, () => {
  console.log(`✅ Servidor a correr em http://localhost:${PORT}`);
});
