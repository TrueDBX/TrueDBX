// controllers/hotels.js
const { getAllHotels } = require("../models/hotels");

// Pesquisar hotéis por localização, datas e nº de hóspedes
function searchHotels(req, res) {
  const { location, checkin, checkout, guests } = req.query;

  let hotels = getAllHotels();

  if (location) {
    hotels = hotels.filter(h => h.location.toLowerCase() === location.toLowerCase());
  }
  if (checkin) {
    hotels = hotels.filter(h => h.checkin <= checkin && h.checkout >= checkin);
  }
  if (checkout) {
    hotels = hotels.filter(h => h.checkout >= checkout && h.checkin <= checkout);
  }
  if (guests) {
    hotels = hotels.filter(h => h.guests >= parseInt(guests));
  }

  res.json(hotels);
}

// Listar todos os hotéis
function listHotels(req, res) {
  res.json(getAllHotels());
}

module.exports = { searchHotels, listHotels };
