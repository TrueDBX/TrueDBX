// controllers/cars.js
const { getAllCars } = require("../models/cars");

// Pesquisar carros por local, data e tipo
function searchCars(req, res) {
  const { location, pickupDate, type } = req.query;

  let cars = getAllCars();

  if (location) {
    cars = cars.filter(c => c.location.toLowerCase() === location.toLowerCase());
  }
  if (pickupDate) {
    cars = cars.filter(c => c.pickupDate === pickupDate);
  }
  if (type) {
    cars = cars.filter(c => c.type.toLowerCase() === type.toLowerCase());
  }

  res.json(cars);
}

// Listar todos os carros
function listCars(req, res) {
  res.json(getAllCars());
}

module.exports = { searchCars, listCars };
