const { getAllReservations, addReservation, deleteReservation } = require("../models/reservations");
const { getAllCars } = require("../models/cars");
const { getAllHotels } = require("../models/hotels");
const { getAllFlights } = require("../models/flights");

// Criar reserva
function createReservation(req, res) {
  const { email, type, itemId } = req.body;

  if (!email || !type || !itemId) {
    return res.status(400).json({ error: "Faltam dados da reserva." });
  }

  const reservations = getAllReservations();
  const newReservation = {
    id: reservations.length + 1,
    email,
    type,
    itemId,
    date: new Date().toISOString()
  };

  addReservation(newReservation);
  res.status(201).json({ message: "Reserva criada com sucesso!", reservation: newReservation });
}

// Listar reservas do utilizador
function listReservations(req, res) {
  const { email } = req.query;
  const reservations = getAllReservations();

  const userReservations = reservations.filter(r => r.email === email);

  // enriquecimento com detalhes
  const enriched = userReservations.map(r => {
    let item = null;
    if (r.type === "car") {
      item = getAllCars().find(c => c.id === r.itemId);
    } else if (r.type === "hotel") {
      item = getAllHotels().find(h => h.id === r.itemId);
    } else if (r.type === "flight") {
      item = getAllFlights().find(f => f.id === r.itemId);
    }
    return { ...r, item };
  });

  res.json(enriched);
}

// Cancelar reserva
function cancelReservation(req, res) {
  const { id } = req.params;
  deleteReservation(parseInt(id));
  res.json({ message: "Reserva cancelada com sucesso!" });
}

module.exports = { createReservation, listReservations, cancelReservation };

