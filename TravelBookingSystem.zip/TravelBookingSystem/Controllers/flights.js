const { getAllFlights } = require("../models/flights");

// Pesquisar voos por origem, destino e data
function searchFlights(req, res) {
  const { origin, destination, date } = req.query; // parâmetros da URL

  let flights = getAllFlights();

  if (origin) {
    flights = flights.filter(f =>
      f.origin.toLowerCase().includes(origin.trim().toLowerCase())
    );
  }
  if (destination) {
    flights = flights.filter(f =>
      f.destination.toLowerCase().includes(destination.trim().toLowerCase())
    );
  }
  if (date) {
    flights = flights.filter(f => f.date === date.trim());
  }

  res.json(flights);
}

// Listar todos os voos
function listFlights(req, res) {
  res.json(getAllFlights());
}

module.exports = { searchFlights, listFlights };
