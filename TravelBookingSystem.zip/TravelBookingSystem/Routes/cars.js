// routes/cars.js
const express = require("express");
const router = express.Router();
const { searchCars, listCars } = require("../controllers/cars");

// GET /cars -> lista todos os carros
router.get("/", listCars);

// GET /cars/search?location=Lisboa&pickupDate=2025-09-20&type=Económico
router.get("/search", searchCars);

module.exports = router;
