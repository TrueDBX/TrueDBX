// routes/flights.js
const express = require("express");
const router = express.Router();
const { searchFlights, listFlights } = require("../controllers/flights");

// GET /flights -> lista todos
router.get("/", listFlights);

// GET /flights/search?origin=Lisboa&destination=Madrid&date=2025-09-20
router.get("/search", searchFlights);

module.exports = router;
