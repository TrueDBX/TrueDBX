const express = require("express");
const router = express.Router();
const { createReservation, listReservations, cancelReservation } = require("../Controllers/reservations");

// POST /reservations -> criar nova reserva
router.post("/", createReservation);

// GET /reservations?email=... -> listar reservas do utilizador
router.get("/", listReservations);

// DELETE /reservations/:id -> cancelar reserva
router.delete("/:id", cancelReservation);

// (Opcional) GET /reservations/all -> listar todas as reservas (admin/debug)
router.get("/all", (req, res) => {
  const { getAllReservations } = require("../models/reservations");
  res.json(getAllReservations());
});

module.exports = router;

