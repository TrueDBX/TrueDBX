// routes/hotels.js
const express = require("express");
const router = express.Router();
const { searchHotels, listHotels } = require("../controllers/hotels");

// GET /hotels -> lista todos os hotéis
router.get("/", listHotels);

// GET /hotels/search?location=Lisboa&checkin=2025-09-20&checkout=2025-09-25&guests=2
router.get("/search", searchHotels);

module.exports = router;
