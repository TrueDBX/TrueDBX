const fs = require("fs");
const path = require("path");
const hotelsFilePath = path.join(__dirname, "../data/hotels.json");

function readHotels() {
  if (!fs.existsSync(hotelsFilePath)) return [];
  const data = fs.readFileSync(hotelsFilePath, "utf-8");
  return JSON.parse(data);
}

function getAllHotels() {
  return readHotels();
}

// Extra (se no futuro quisere adicionar novos hoteis pelo backend)
function addHotel(hotel) {
  const hotels = readHotels();
  hotel.id = hotels.length ? hotels[hotels.length - 1].id + 1 : 1;
  hotels.push(hotel);
  fs.writeFileSync(hotelsFilePath, JSON.stringify(hotels, null, 2));
  return hotel;
}

module.exports = { getAllHotels, addHotel };
