// models/cars.js
const fs = require("fs");
const path = require("path");
const carsFilePath = path.join(__dirname, "../data/cars.json");

function readCars() {
  if (!fs.existsSync(carsFilePath)) return [];
  const data = fs.readFileSync(carsFilePath, "utf-8");
  return JSON.parse(data);
}

function getAllCars() {
  return readCars();
}

// Extra (se no futuro quisere adicionar novos carros pelo backend)
function addCar(car) {
  const cars = readCars();
  car.id = cars.length ? cars[cars.length - 1].id + 1 : 1;
  cars.push(car);
  fs.writeFileSync(carsFilePath, JSON.stringify(cars, null, 2));
  return car;
}

module.exports = { getAllCars, addCar };
