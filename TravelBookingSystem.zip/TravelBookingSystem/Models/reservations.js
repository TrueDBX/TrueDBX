const fs = require("fs");
const path = require("path");
const reservationsFilePath = path.join(__dirname, "../data/reservations.json");

function readReservations() {
  if (!fs.existsSync(reservationsFilePath)) return [];
  const data = fs.readFileSync(reservationsFilePath);
  return JSON.parse(data);
}

function writeReservations(reservations) {
  fs.writeFileSync(reservationsFilePath, JSON.stringify(reservations, null, 2));
}

function getAllReservations() {
  return readReservations();
}

function addReservation(reservation) {
  const reservations = readReservations();
  reservations.push(reservation);
  writeReservations(reservations);
}

function deleteReservation(id) {
  let reservations = readReservations();
  reservations = reservations.filter(r => r.id !== id);
  writeReservations(reservations);
}

module.exports = { getAllReservations, addReservation, deleteReservation };
