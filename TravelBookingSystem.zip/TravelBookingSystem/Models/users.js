const fs = require("fs");
const path = require("path");
const usersFilePath = path.join(__dirname, "../Data/users.json");

function readUsers() {
  if (!fs.existsSync(usersFilePath)) return [];
  const data = fs.readFileSync(usersFilePath);
  return JSON.parse(data);
}

function writeUsers(users) {
  fs.writeFileSync(usersFilePath, JSON.stringify(users, null, 2));
}

function getAllUsers() {
  return readUsers();
}

function addUser(user) {
  const users = readUsers();
  users.push(user);
  writeUsers(users);
}

module.exports = { getAllUsers, addUser };
