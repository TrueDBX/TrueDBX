const fs = require("fs");
const path = require("path");
const flightsFilePath = path.join(__dirname, "../data/flights.json");

function readFlights() {
  if (!fs.existsSync(flightsFilePath)) return [];
  const data = fs.readFileSync(flightsFilePath, "utf-8");
  return JSON.parse(data);
}

function getAllFlights() {
  return readFlights();
}

// Extra (se no futuro quisere adicionar novos Avioes pelo backend)
function addFlight(flight) {
  const flights = readFlights();
  flight.id = flights.length ? flights[flights.length - 1].id + 1 : 1;
  flights.push(flight);
  fs.writeFileSync(flightsFilePath, JSON.stringify(flights, null, 2));
  return flight;
}

module.exports = { getAllFlights, addFlight };
